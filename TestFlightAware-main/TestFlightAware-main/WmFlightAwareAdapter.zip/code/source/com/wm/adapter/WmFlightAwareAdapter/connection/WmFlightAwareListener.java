package com.wm.adapter.WmFlightAwareAdapter.connection;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import javax.resource.ResourceException;

import com.google.gson.JsonSyntaxException;
import com.wm.adapter.WmFlightAwareAdapter.WmFlightAwareAdapter;
import com.wm.adapter.WmFlightAwareAdapter.WmFlightAwareConstants;
import com.wm.adk.metadata.WmDescriptor;
import com.wm.adk.notification.ClusterAware;
import com.wm.adk.notification.WmConnectedListener;
import com.wm.adk.notification.WmNotification;
import com.wm.adk.error.AdapterException;

public class WmFlightAwareListener extends WmConnectedListener implements WmFlightAwareConstants, ClusterAware {

	
	public WmFlightAwareListener() {
		super();
	}

	@Override
	public void fillWmDescriptor(WmDescriptor d, Locale l) throws ResourceException {
		d.setDescriptions(WmFlightAwareAdapter.getInstance().getAdapterResourceBundleManager(), l);

	}

	@Override
	public void listenerShutdown() {
		// notify Sample Server to switch client connection to interaction
		// mode
		try {
			((WmFlightAwareAdapterConnection) retrieveConnection()).destroyConnection();
		} catch (ResourceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void listenerStartup() throws ResourceException {
		//HOW CAN I INITIALIZE CONNECTION HERE MANUALLY?
		((WmFlightAwareAdapterConnection)retrieveConnection()).initializeConnection(null, null);

	}

	@Override
	public Object waitForData() throws ResourceException {
		List notifications = getRegisteredNotifications();
		int numberOfNotifications = notifications.size();
		while (numberOfNotifications > 0) {
			// Get last notification in list
			WmNotification last = (WmNotification) notifications.get(numberOfNotifications - 1);
			if (((WmNotification) last).enabled())
				break;
			numberOfNotifications--;
		}
		
		if (numberOfNotifications == 0) {
			WmFlightAwareAdapter.retrieveLogger().logInfo(LISTENER_NOTIFICATION_NOT_AVAILABLE,
					new String[] { this._listenerNodeName.getFullName() });
			try {
				Thread.sleep(5000);
			} catch (InterruptedException ie) {
			}
			return null;
		}
		
		FlightObject output=null;
		try {
			output = ((WmFlightAwareAdapterConnection) retrieveConnection()).receiveFlightAllowTimeout();
		} catch (JsonSyntaxException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return output;
	}

}

package com.wm.adapter.WmFlightAwareAdapter.connection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Locale;

import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.resource.ResourceException;
import javax.resource.spi.ConnectionRequestInfo;
import javax.security.auth.Subject;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.wm.adapter.WmFlightAwareAdapter.WmFlightAwareAdapter;
import com.wm.adapter.WmFlightAwareAdapter.WmFlightAwareConstants;
import com.wm.adk.connection.WmManagedConnection;
import com.wm.adk.connection.WmManagedConnectionFactory;
import com.wm.adk.error.AdapterConnectionException;
import com.wm.adk.error.AdapterException;
import com.wm.adk.info.ResourceAdapterMetadataInfo;
import com.wm.adk.metadata.ResourceDomainValues;
import com.wm.adk.metadata.WmAdapterAccess;
import com.wm.adk.metadata.WmDescriptor;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;


public class WmFlightAwareAdapterConnection extends WmManagedConnection implements WmFlightAwareConstants {

	private static OutputStreamWriter  writer = null;
	private static  BufferedReader  reader = null;
	private static InputStream  inputStream = null;
	private static  SSLSocket  ssl_socket = null;
	private String _flightAwareUserName = "aysuyanar";
	private String _flightAwarePassword = "98769bc3cdf001e1cc5ddf1be0436794c6b5ae3d";
	
	String initiation_command = "";
	private static final boolean useCompression = false;
	String machineName = "firehose.flightaware.com";
	 
	public WmFlightAwareAdapterConnection(String flightAwareUserName, String flightAwarePassword) {
		_flightAwareUserName=flightAwareUserName;
		_flightAwarePassword=flightAwarePassword;
		initiation_command = "live username "+_flightAwareUserName+" password "+_flightAwarePassword;
		
		WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"I am WmFlightAwareAdapterConnection "+ initiation_command + "machineName"+ machineName);
	}
    /*
     * Specifies that initialization is required immediately after a connection
     * is created for the first time.
     */
    protected boolean initializationRequired() {
        return true;
    }
	protected void initializeConnection(Subject subject,ConnectionRequestInfo requestInfo) throws ResourceException{
		
		WmFlightAwareAdapter.retrieveLogger().logInfo(CONNECTION_INITILIZATION);
		WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"I am initializeConnection() ");
		try {
			
			SSLSocket ssl_socket;
			SSLParameters sslParams = new SSLParameters();
			sslParams.setEndpointIdentificationAlgorithm("HTTPS");
			sslParams.setProtocols(new String[] {"TLSv1.2"});
			   ssl_socket = (SSLSocket) SSLSocketFactory.getDefault().createSocket(machineName, 1501);
			// enable certifcate validation:
			   ssl_socket.setSSLParameters(sslParams);
			   initiation_command += "\n";
			
			   //send your initiation command
			   writer = new OutputStreamWriter(ssl_socket.getOutputStream(), "UTF8");
			   writer.write(initiation_command);
			   writer.flush();
			
			   inputStream = ssl_socket.getInputStream();
			   		
			   // read messages from FlightAware
			   reader = new BufferedReader(new InputStreamReader(inputStream));
			
			
		//modbusClient = new ModbusClient(_serverHost,Integer.parseInt(_serverPort));
		WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"******* WmFlightAwareAdapterConnection Established"+ "**********");
		//this.connectFlightAwareServer(); -> RunClient(String machineName)
		}
		catch(Exception e) {
			 AdapterConnectionException ace = WmFlightAwareAdapter.getInstance().createAdapterConnectionException(
           		  RESOURCE_CONN_EXCEPTION, null, e);
		        ace.setFatal(true);
		        throw ace;
		}
		

	}

	@Override
	public Boolean adapterCheckValue(String arg0, String arg1, String[][] arg2, String arg3) throws AdapterException {
		
		WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"I am adapterCheckValue() ");
		return null;
	}



	@Override
	protected void destroyConnection() throws ResourceException {
		WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"I am destroyConnection() ");
		WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"I am destroyConnection() doing nothing ");
		 try {
		 writer.close();
         reader.close();
         inputStream.close();
         ssl_socket.close();
         
			 } catch (IOException e) {
				AdapterConnectionException ace = WmFlightAwareAdapter.getInstance().createAdapterConnectionException(
		           		  RESOURCE_CONN_EXCEPTION, null, e);
				        ace.setFatal(true);
				        throw ace;
			}
		
	}

	@Override
	public void registerResourceDomain(WmAdapterAccess access) throws AdapterException {
		WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"I am registerResourceDomain() ");
		// added at Phase 5 to support listener notification
		try {
            access.addResourceDomainLookup(null, OUTPUT_PARAMETER_NAMES_RD, this);
            access.addResourceDomainLookup(null, OUTPUT_FIELD_TYPES_RD, this);
            access.addResourceDomainLookup(null, OUTPUT_FIELD_NAMES_RD, this);
		access.addResourceDomainLookup(null, NOTIFICATION_NAMES_RD, this);
	} catch (Exception ex) {
		throw WmFlightAwareAdapter.getInstance().createAdapterException(RESOURCE_DOMAIN_EXCEPTION, ex);
	}
	}


	@Override
	public ResourceDomainValues[] adapterResourceDomainLookup(String serviceName, String resourceDomainName, String[][] values)
			throws AdapterException {
		
		WmFlightAwareAdapter.retrieveLogger().logInfo(RESOURCE_DOMAIN_LOOKUP);
		WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"I am adapterResourceDomainLookup() ");
		
		String[] fieldNames = null;
        String[] fieldTypes = null;
		
		if (resourceDomainName.equals(NOTIFICATION_NAMES_RD)) {
			return new ResourceDomainValues[] {
                    new ResourceDomainValues(resourceDomainName, new String[] {"Flight Aware Sync Listener"})};
		}
		else if (resourceDomainName.equals(OUTPUT_PARAMETER_NAMES_RD)
				|| resourceDomainName.equals(OUTPUT_FIELD_TYPES_RD)) {
			
			fieldNames = new String[] {"FlightObject"};
        	fieldTypes = new String[] {"java.lang.String"};
        	
			  return new ResourceDomainValues[] {
            		new ResourceDomainValues(OUTPUT_FIELD_TYPES_RD, fieldTypes),
            		new ResourceDomainValues(OUTPUT_FIELD_NAMES_RD, fieldNames),
            		new ResourceDomainValues(OUTPUT_PARAMETER_NAMES_RD, fieldNames)};
            
		} 
		// because input parameters and input field types have been declared
		// as
		else
			// return nothing at Phase 2
			return null;
	}
	
	public FlightObject receiveFlightAllowTimeout() throws JsonSyntaxException, IOException {
		WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"I am receiveFlightAllowTimeout() ");
		String message = null;
		FlightObject flightObj=null;
		   int limit = 10; //limit number messages for testing
		   Gson gson = new Gson();
		   SSLSocket ssl_socket;
			SSLParameters sslParams = new SSLParameters();
			sslParams.setEndpointIdentificationAlgorithm("HTTPS");
			sslParams.setProtocols(new String[] {"TLSv1.2"});
			   ssl_socket = (SSLSocket) SSLSocketFactory.getDefault().createSocket(machineName, 1501);
			// enable certifcate validation:
			   ssl_socket.setSSLParameters(sslParams);
			   initiation_command += "\n";
			
			   //send your initiation command
			   writer = new OutputStreamWriter(ssl_socket.getOutputStream(), "UTF8");
			   writer.write(initiation_command);
			   writer.flush();
			
			   inputStream = ssl_socket.getInputStream();
			   		
			   // read messages from FlightAware
			   reader = new BufferedReader(new InputStreamReader(inputStream));
		   //pipeline.
		   IData flightDoc = IDataFactory.create();  
		   //IDataCursor flightCursor = flightDoc.getCursor();  
		   //IDataUtil.put( inputCursor, "Flight", "input1" );	
		   WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"I am receiveFlightAllowTimeout() size of reader " + reader.ready());
		   while (limit > 0 && (message = reader.readLine()) != null) 
		   {
			   WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"msg: " + message + " flight Nr: "+ limit);
		      // System.out.println("msg: " + message + " flight Nr: "+ limit);
		       flightObj = gson.fromJson(message, FlightObject.class);
		       //parse message with gson
		       System.out.printf("---------------- flightObj ---------------------\n " +flightObj);
		       limit--;
		   /*    IData flight = IDataFactory.create();
		       IDataCursor cursor = flight.getCursor();  
		       IDataUtil.put(cursor, "type", flightObj.type);
		       IDataUtil.put(cursor, "ident", flightObj.ident);
		       IDataUtil.put(cursor, "air_ground", flightObj.air_ground);
		       IDataUtil.put(cursor, "alt", flightObj.alt);
		       IDataUtil.put(cursor, "clock", flightObj.clock);
		       IDataUtil.put(cursor, "id", flightObj.id);
		       IDataUtil.put(cursor, "gs", flightObj.gs);
		       IDataUtil.put(cursor, "heading", flightObj.heading);
		       IDataUtil.put(cursor, "lat", flightObj.lat);
		       IDataUtil.put(cursor, "lon", flightObj.lon);
		       IDataUtil.put(cursor, "reg", flightObj.reg);
		       IDataUtil.put(cursor, "squawk", flightObj.squawk);
		       IDataUtil.put(cursor, "updateType", flightObj.updateType);  
		       IDataUtil.append(flightDoc, flight);
		       cursor.destroy();*/
		   }
		   //IDataCursor master=pipeline.getCursor();
		//   System.out.println("---****flight"+flightObj);
		   WmFlightAwareAdapter.retrieveLogger().logInfo(9999,"---****fligyt"+flightObj);
		   
		   //System.out.println("---****fligyt"+pipeline);
		 //  IDataUtil.append(pipeline, flightDoc);
		   return flightObj;
	}
}
